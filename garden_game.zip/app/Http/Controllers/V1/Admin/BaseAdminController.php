<?php

namespace App\Http\Controllers\V1\Admin;

use App\Http\Controllers\Controller;
use App\Trait\Response;
use Illuminate\Http\Request;

class BaseAdminController extends Controller
{
    use Response;
}
