<?php

namespace App\Http\Controllers\V1\User;

use App\Trait\Response;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BaseUserController extends Controller
{
    use Response;
}
