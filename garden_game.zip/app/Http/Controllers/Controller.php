<?php

namespace App\Http\Controllers;

use App\Trait\Response;

abstract class Controller
{
    use Response;
}
